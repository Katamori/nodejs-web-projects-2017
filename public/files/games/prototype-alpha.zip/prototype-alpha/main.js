var gameX = 1024;
var gameY = 512;

var tilesize = 32;
var mapsize = 36;

var playerStats = {
  'sizeX': tilesize*3,
  'sizeY': tilesize*3,
  'speed': 200
}

var texts = [];

var game = new Phaser.Game(gameX, gameY, Phaser.AUTO, '',
    { preload: preload, create: create, update: update, render: render });



function preload(){

  var folder = '/files/games/prototype-alpha/';
  var GFX = folder + 'gfx/';

  game.load.image('katamori', GFX + 'katamori.png');

  game.load.spritesheet('tileset', GFX + 'tileset.png', tilesize, tilesize);

  game.time.advancedTiming = true;
}




function create(){

  game.physics.startSystem(Phaser.Physics.ARCADE);
  drawable = game.add.group();

  map = game.add.tilemap();

  map.addTilesetImage('tileset');

  map.setCollision([1,3]);

  layer = map.create('level', mapsize, mapsize, tilesize, tilesize);
  layer.resizeWorld();
  drawable.add(layer);




  for(i=0;i<map.width;i++){
      for(j=0;j<map.height;j++){

          map.putTile(0, i, j, layer)
          //if(i==0||j==0){map.putTile(1, i, j, layer)}else{map.putTile(0, i, j, layer)}

      };
  };

  map.putTile(1, 5,5, layer);

  //define player
  Create_Player('katamori', 256, 256);

  cursors = game.input.keyboard.createCursorKeys();

  drawable.sort();

  //titlepic.inputEnabled = true;
  //titlepic.input.useHandCursor = true;
  //titlepic.events.onInputDown.add(destroySprite, this);


}

function update(){

  mouseX = game.input.mousePointer.x;
  mouseY = game.input.mousePointer.y;

  game.physics.arcade.collide(player, layer);

  player.body.velocity.x = 0;
  player.body.velocity.y = 0;

  if (cursors.up.isDown) {        player.body.velocity.y = -playerStats.speed};
  if (cursors.left.isDown) {      player.body.velocity.x = -playerStats.speed};
  if (cursors.right.isDown) {     player.body.velocity.x = playerStats.speed};
  if (cursors.down.isDown) {      player.body.velocity.y = playerStats.speed};

}

function render(){

  game.debug.text("FPS: "+game.time.fps, gameX - 80, 64);
  //game.debug.body(player);

}
