function print(name, string, x, y) {

    var style = {font: "16px Arial", fill: "white", align: "left"};

    //texts[] should exist when and/or where it's called
    if (typeof texts[name] != 'object'){
      texts[name] = game.add.text(x, y, string, style);
    }


};
/*
function destroySprite (sprite) {

    sprite.visible = false;

}
*/
function Create_Player(sheet, x, y){

    player = game.add.sprite(x, y, sheet);
    drawable.add(player);
/*
    player.animations.add('run right', [1,2], 3, true, true);
    player.animations.add('run left', [4, 5], 3, true, true);
*/
    game.physics.arcade.enable(player);

    player.body.bounce.y = 0.1;
    player.body.collideWorldBounds = true;
    player.body.setSize(playerStats.sizeX, playerStats.sizeY, 0, 0);


    game.camera.follow(player);

};
